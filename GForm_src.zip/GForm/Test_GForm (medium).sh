#!/usr/bin/env bash

# This is a medium advanced example bash script to show how to use GForm to create a GUI
# and then have your shell script act upon the input by sending commands back to the GUI
# to modify the data.


# Set up our name list and run Gform.gambas with some args.
NameArray=(Fred Freda "Uncle Bob" Sally)
for s in "${NameArray[@]}"; do txt="$txt,$s"; done
NameList=${txt#,*} ; ListIndex=0

# The following is one long line split using \ to make things clearer
# as each line is each row in the form. note, using option 'quiet' to
# suppress any stdout message unlike the 'Test_GForm (simple).sh' example.

./GForm quiet font="Carlito,14,Italic" pipe="/tmp/fifo1" listen="/tmp/fifo2" title="GForm shell script example" \
box button="btnAdd|Add Name" button="btnDel|Del Name" spring unbox \
box label="Modify name" input="inp1|Fred" unbox \
box checkbox="c1|Got a check box too|on" combobox="cb1|$NameList|0|stretch" unbox \
listbox="lb1|$NameList" \
fontbox="fnt1|nostretch" \
box spring button="BQ|Quit Button|close"&sleep 1


CleanUp() {
exec 3<&- 2>/dev/null # close the pipe handle
if [ -e "/tmp/fifo2" ]; then
rm /tmp/fifo2
fi
if [ -e "/tmp/fifo1" ]; then
rm /tmp/fifo1
fi

exit
}

ArrayToList() {
txt=""
for s in "${NameArray[@]}"; do txt="$txt,$s"; done
NameList=${txt#,*}
}

Alert() {  # just using the GUI to pop a message
if [ "$2" = "w" ]; then
Send "disable"
gbr3 GForm quiet toponly title="Notice.." label="$1" button="|Okay|close" 2>/dev/null
Send "enable"
sleep 0.3 # give the GUI a moment to become enabled again
else
gbr3 GForm quiet toponly title="Notice.." label="$1" button="|Okay|close" 2>/dev/null&false
fi
}

Send() {
echo -e "$1\n" >/tmp/fifo2
}

DoCommand() {  
# this is the main function for processing the data coming from the GUI.
# The message will be in the form of "object_name|object_text|object_value"

if [ "$ACTIVE" = "no" ]; then  # set ACTIVE to "no" to disable this routine
return
fi

CName=${PipeText%%|*}   # get the name of the control talking to us.

TMP=${PipeText#*|}
if [[ "$TMP" = *"|"* ]]; then
 CText=${TMP%|*}        # see if rest of message has another field.
 CData=${TMP#*|}        # Toggle buttons, checkboxes, etc have other info
else
 CText="$TMP"
 CData=""
fi

# message has now been split into $CName , $CText and $CData
# so we can add our procedures here according to the GUI data.

if [ "$CName" = "btnAdd" ]; then 
ListIndex="${#NameArray[@]}"
if [ "$NameList" = "" ]; then 
Send "enable=btnDel"; sleep 0.1; fi

NameArray+=( "New Name" )
ArrayToList
Send "stop\nsetlist=lb1|$NameList\nsetlist=cb1|$NameList\nstart\nsetindex=lb1|$ListIndex"

elif [ "$CName" = "btnDel" ]; then 
if [ ${#NameArray[@]} -eq 1 ]; then
NameArray=( ) ; NameList=""
else
NameArray=( "${NameArray[@]:0:$((ListIndex))}" "${NameArray[@]:$ListIndex+1}" )
ArrayToList
fi

if [ "$ListIndex" -ge ${#NameArray[@]} ]; then ((ListIndex--)); fi

Send "setlist=lb1|$NameList\nsetlist=cb1|$NameList\n"\
"setindex=lb1|$ListIndex"
#echo $NameArray 
if [ "$NameList" = "" ]; then 
sleep 0.2
Send "disable=btnDel\n"\
"settext=inp1|"; fi

elif [ "$CName" = "c1" ]; then
 Alert "The Checkbox $CName it's now '$CData'" "w"

elif [ "$CName" = "inp1" ]; then
NameArray[$ListIndex]="$CText"
TMP=$ListIndex
ArrayToList
Send "stop\nsetlist=lb1|$NameList\nsetlist=cb1|$NameList\nsetindex=cb1|$TMP\nstart"

elif [ "$CName" = "fnt1" ]; then
Send "mainfont=$CText"

elif [ "$CName" = "lb1" ]; then
 ListIndex=$CData
 Send "settext=inp1|$CText\nstop\nsetindex=cb1|$ListIndex\nstart"

elif [ "$CName" = "cb1" ]; then
 ListIndex=$CData       # Remember the list position
 Send "settext=inp1|$CText\nstop\nsetindex=lb1|$ListIndex\nstart"

elif [ "$CName" = "BQ" ]; then
 Alert "You've Exited." "w"
 CleanUp
else
Alert "unknown message\n$PipeText" "w"
fi

}


# Main()
# This is the main loop, It opens the pipe and if a line of text comes
# through it reads it to $Pipetext and runs the DoCommand() procedure above.
# Closing the GUI deletes the pipe file so our loop runs while the file exists.

exec 3</tmp/fifo1 
  while [ -e "/tmp/fifo1" ]; do
  read -u 3 PipeText
   if [ ! -z "$PipeText" ]; then  # We got some text so process it.
    DoCommand
   fi
  done

CleanUp  # clean up and exit.


