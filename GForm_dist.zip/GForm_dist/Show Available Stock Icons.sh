#!/usr/bin/env bash

./GForm geticons

