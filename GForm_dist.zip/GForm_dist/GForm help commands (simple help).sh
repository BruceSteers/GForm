#!/usr/bin/env bash

./GForm help

