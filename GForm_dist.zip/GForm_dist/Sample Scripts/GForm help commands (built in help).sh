#!/usr/bin/env bash

# Shows GForm built in help 
# also shows using GForm as a simple choice requester using the 'com=' flag to execute a command on button click.


../GForm topmost quiet label="|\nSelect the type of help\nyou would like to view\n" \
box \
button="0|Show Command Help|com=../GForm help" \
button="1|Show All Help|com=../GForm fullhelp" 2>/dev/null

