#!/usr/bin/env bash

# Shows GForm built in help 
# also shows using GForm as a simple choice requester and getting result as a variable $RES


RES=$(../GForm topmost returnval button="0|Show Command Help" button="1|Show All Help")

if [ $RES = "0" ]; then
../GForm help
elif [ $RES = "1" ]; then
../GForm fullhelp
fi

