#!/usr/bin/env bash

# This is a medium example Template bash script to show how to use GForm to create a GUI
# and then have your shell script act upon the input by sending commands back to the GUI
# to modify the data. This is a minimal as can be for you to re-write for your own needs.



IFS=$'\n'
GFORM='../GForm'

# The following is one long line split using \ to make things clearer
# as each line is each row in the form. note, using option 'quiet' to
# suppress any stdout message unlike the 'Test_GForm (simple).sh' example.

RunGForm() {
ClearPipes 

gbr3 "$GFORM" quiet pipe="/tmp/fifo1" listen="/tmp/fifo2" title="GForm Template shell script example" \
button="BTN_1|Click to toggle the checkBox" \
checkbox="cb1|This is the CheckBox" \
box spring button="BQ|Quit Button|close icon=quit" 2>/dev/null&false

 while [ ! -e "/tmp/fifo1" ]; do sleep 0.1;  done
}

# Delete any old pipe files that may exist
ClearPipes() {
if [ -e "/tmp/fifo2" ]; then rm /tmp/fifo2; fi
if [ -e "/tmp/fifo1" ]; then rm /tmp/fifo1; fi
}

CleanUp() {
exec 3<&- 2>/dev/null # close the pipe handle
ClearPipes
exit
}

Alert() {  
# This just uses GForm to pop up a message box. if the pipe file has gone then the GUI has closed
# so it launches GForm again otherwise it uses the running GUI's internal "message" function.
if [ ! -e "/tmp/fifo1" ]; then 
gbr3 "$GFORM" quiet toponly title="Notice.." label="|$1" button="|Okay|close" 2>/dev/null
return
fi
SendE "message=$1"
}

# Commands to send text to the GUI via the listening pipe , there are 2 styles of sending...
Send() { echo -e "$1" >>/tmp/fifo2; }  # treats linefeeds '\n' as actual newlins and sends multiple lines
SendE() { echo -E "$1" >>/tmp/fifo2; } # treats linefeeds '\n' as text and sends one line with '\n' chars

# this function splits the incoming GUI message "name|text|data" into $CName, $CText and $CData variables.
TextToData() {
PT=$1
CName=${PT%%|*}   # get the name of the control talking to us. left of the first '|' char
TMP=${PT#*|}      # remove the name| part and see whats left (or right to be exact)

# see if rest of message has another field. CheckBoxes, etc have other info but buttons do not.
if [[ "$TMP" = *"|"* ]]; then
 CText=${TMP%|*};  CData=${TMP#*|}
else
 CText="$TMP";     CData=""
fi
}


DoCommand() {  
# this is the main function for processing the data coming from the GUI.
# The message will be in the form of "object_name|object_text|object_value"

if [ "$ACTIVE" = "no" ]; then  # set ACTIVE to "no" to disable this routine
return
fi

if [ "$CName" = "BTN_1" ]; then 
Send "toggle=cb1"

elif [ "$CName" = "cb1" ]; then 
echo "Checking the box $CData"

elif [ "$CName" = "BQ" ]; then
 Alert "You've Exited." "w"
 CleanUp 
else
Alert "Unknown or unhandled message\n$1" "w"
fi

}


# Main()
# This is the main loop, It opens the pipe and if a line of text comes
# through it reads it to $Pipetext and runs the DoCommand() procedure above.
# Closing the GUI deletes the pipe file so our loop runs while the file exists.

RunGForm

exec 3</tmp/fifo1 
  while [ -e "/tmp/fifo1" ]; do
  read -u 3 PipeText
   if [ ! -z "$PipeText" ]; then  # We got some text so process it.
   TextToData $PipeText
    DoCommand $PipeText
   fi
  done

CleanUp  # clean up and exit.


