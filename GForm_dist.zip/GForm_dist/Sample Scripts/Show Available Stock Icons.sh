#!/usr/bin/env bash
# Call GForm geticons to show all available stock icons and their names.

../GForm geticons 2>/dev/null

