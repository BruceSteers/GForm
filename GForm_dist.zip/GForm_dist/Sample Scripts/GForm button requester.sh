#!/usr/bin/env bash

ANS=$(../GForm allstretch return=t width=350 title="GForm button requester example" \
label="|\nthis is an example of a multiple row button requester\nPressing any button will return the button text to the shell\n" \
box button="|Option 1" button="|Option 2" button="|Option 3" unbox \
box button="|Option 4" button="|Option 5" button="|Quit")

echo "$ANS"

../GForm quiet toponly title="Notice.." label="|$ANS was the selection" button="|Okay|close"

