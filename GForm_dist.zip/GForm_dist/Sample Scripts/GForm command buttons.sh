#!/usr/bin/env bash

# Simple example to show how GForm can be used to create buttons with commands attached to them.
# using the 'com=command' flag we can have buttons auto run shell commands.
# This saves the need to add an event handler to the script as it's all handled by GForm internally.
# most commands here use 'xdg-open /location' to open your file manager at said location.
# use '\"' for quote marks and \n for newline in commands.


WB="icon=link foreground=50,50,255"  # set blue text colour variable for the web links.

../GForm allstretch spacing font="Carlito,14,Italic" bg=150,200,200 topmost quiet width=350 title="GForm command button requester example" \
label="|\nThis is an example of a command button requester.\nPressing any button will run a command so your script\ndoesn't have to.\n(mostly just using xdg-open on a location/URL)\n|center lines=5 background=200,200,200" \
box button="|Run Gambas IDE|com=gambas3|icon=gambas" button="|Open home Dir|com=xdg-open \"$HOME\"|icon=open" unbox \
label="|Web pages..|left nostretch" \
box button="|Gambas wiki|com=xdg-open \"http://gambaswiki.org/wiki\"|$WB" button="|Gambas homepage|com=xdg-open http://gambas.sourceforge.net/|$WB" unbox \
box button="|GForm website|com=xdg-open http://gform.bws.org.uk|$WB" button="|GForm on github|com=xdg-open https://github.com/BruceSteers/GForm|$WB" unbox \
box button="|Gambas one|com=xdg-open http://wordpress.gambas.one/|$WB" button="|GambasOne forums|com=xdg-open https://forum.gambas.one/|$WB" unbox \
box button="tst|Test|icon=play nostretch|com=cd $HOME\nls -1\necho \"All done\"" spring button="|Close window|close nostretch icon=quit" 2>/dev/null

