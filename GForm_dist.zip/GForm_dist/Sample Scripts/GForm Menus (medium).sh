#!/usr/bin/env bash

# This is a medium advanced example bash script to show how to use GForm to create a GUI
# and then have your shell script act upon the input by sending commands back to the GUI
# to modify the data.

# This example is showing the use of the menu items

if [ -e "/tmp/fifo2" ]; then rm /tmp/fifo2; fi
if [ -e "/tmp/fifo1" ]; then rm /tmp/fifo1; fi

# The following is one long line split using \ to make things clearer
# as each line is each row in the form. note, using option 'quiet' to
# suppress any stdout message unlike the 'Test_GForm (simple).sh' example.

../GForm quiet font="Carlito,14,Italic" pipe="/tmp/fifo1" listen="/tmp/fifo2" title="GForm medium advanced shell script example" width=350 \
menu="mMain||Main Menu" menu="mHidePU|mMain|Hide Popup Menu on Button|toggle icon=watch" menu="BQ|mMain|Quit|icon=quit close" \
menu="mInfo||Info Menu" menu="mHelp|mInfo|Help|icon=help" menu="mAbout|mInfo|About|icon=about" \
menu="mPopUp||..|hidden" menu="mPU1|mPopUp|Popup menu item|icon=menu" \
label="lbl|Select a menu function...|stretch" \
box button="bPopup|Right Click me|menu=mPopUp icon=menu" spring button="BQ|Quit Button|close icon=quit"&false

 while [ ! -e "/tmp/fifo1" ]; do
 sleep 0.1
 done
AppOpen=1

CleanUp() {
exec 3<&- 2>/dev/null # close the pipe handle
if [ -e "/tmp/fifo2" ]; then
rm /tmp/fifo2
fi
if [ -e "/tmp/fifo1" ]; then
rm /tmp/fifo1
fi

exit
}

Alert() {  
# just using GForm to pop up a message box. 
#gbr3 ../GForm quiet toponly title="Notice.." label="|$1" button="|Okay|close" 2>/dev/null
SendE "message=$1"
}

Send() { echo -e "$1" >>/tmp/fifo2; }
SendE() { echo -E "$1" >>/tmp/fifo2; }

TextToData() {
PT=$1
CName=${PT%%|*}   # get the name of the control talking to us.
TMP=${PT#*|}
if [[ "$TMP" = *"|"* ]]; then
 CText=${TMP%|*}        # see if rest of message has another field.
 CData=${TMP#*|}        # Toggle buttons, checkboxes, etc have other info
else
 CText="$TMP"
 CData=""
fi
}


DoCommand() {  
# this is the main function for processing the data coming from the GUI.
# The message will be in the form of "object_name|object_text|object_value"

if [ "$CName" = "Comp" ]; then 
echo "Compiling"

elif [ "$CName" = "Inst" ]; then 
echo "Making install script"

elif [ "$CName" = "mAbout" ]; then 
echo "Talk about ....."
sleep 0.5; echo Pop; sleep 0.5; echo Pop; sleep 0.5; echo "Pop Music"

elif [ "$CName" = "mHelp" ]; then 
echo "HEEEELP!!!....."

elif [ "$CName" = "bPopup" ]; then
Alert "That wasn't a right click\nbut i don't mind :)"

elif [ "$CName" = "mHidePU" ]; then 
if [ "$CData" = "True" ]; then
Send "setpopup=bPopup|\nsettext=bPopup|Click Me"
else
Send "setpopup=bPopup|mPopUp\nsettext=bPopup|Right Click Me"
fi

elif [ "$CName" = "mPU1" ]; then
Alert "Theres that popup menu click"

elif [ "$CName" = "BQ" ]; then
AppOpen=0
 Alert "You've Exited." "w"
 CleanUp 
else
Alert "Unknown message recieved\n$1"
fi

}


# Main()
# This is the main loop, It opens the pipe and if a line of text comes
# through it reads it to $Pipetext and runs the DoCommand() procedure above.
# Closing the GUI deletes the pipe file so our loop runs while the file exists.

IFS=$'\n'
exec 3</tmp/fifo1 
  while [ -e "/tmp/fifo1" ]; do
  read -u 3 PipeText
   if [ ! -z "$PipeText" ]; then  # We got some text so process it.
   TextToData $PipeText
    DoCommand $PipeText
   fi
  done

CleanUp  # clean up and exit.


