#!/usr/bin/env bash
# Gambas component Installer script for Gambas basic application 'GForm'
# Script created by GambasTweak by Bruce Steers
# Must be run from terminal, will give option to install full Gambas3 or minimum components

# Function to check for installed package installer
GetPKGR() {
echo "Checking for installed packager apt, yum or dnf..."
PKGR=$(which apt-get)
if [ "$PKGR" = "" ]; then
 PKGR=$(which yum)
 if [ "$PKGR" = "" ]; then
  PKGR=$(which dnf)
  if [ "$PKGR" = "" ]; then
  echo -n "Sorry cannot find your package installer\nPress return to exit."
  read
  exit
  fi
 fi
fi

echo "found packager '$PKGR', for install okay."
}

# Function to ask user what type of install they want and start installing...
SelectInstall() {
echo "Install $AppName's minimum required gambas components or the complete Gambas3 package?"
echo -ne "Press return for minimum components (default) or type 'f' for full Gambas3\nor Ctrl-C to cancel: "
read REPLY
if [ "$REPLY" = "f" ]; then
 echo "Installing the complete Gambas3 developement package..."
 sudo "$PKGR" install gambas3
else
 echo "Installing minimum required Gambas3 components only for '$AppName'..."
 sudo "$PKGR" install $REQS
fi

echo "All finished, press return to exit."
read
exit
}

REQS=""
RT_Yes=$(which gbr3)
if [ -z "$RT_Yes" ]; then REQS=" gambas3-runtime"; fi

AppName="GForm"
REQS="gambas3-gb-image gambas3-gb-gui-qt gambas3-gb-form gambas3-gb-form-stock$REQS"
GetPKGR
SelectInstall

# Script end
