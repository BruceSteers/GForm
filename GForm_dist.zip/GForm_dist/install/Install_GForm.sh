#!/usr/bin/env bash
# Installer script for Gambas basic application 'GForm'
# Script created by GambasTweak by Bruce Steers
# Must be run from terminal, Defaults to 'bin' directory, will give option to type or browse (if zenity exists) a different dir

# Ask for install dir and copy the executable there.
CopyApplication() {

ZEN=$(which zenity)
SDIR=$(which bash); SDIR=${SDIR%/*}

echo "Install $AppName..."
echo "Press return to install to $SDIR or type a new path now (without trailing /)"
if [ ! -z "$ZEN" ]; then echo "Or type 'z' to open a path chooser to browse"; fi
echo -n "Or press Ctrl-C to cancel: "
read REPLY
if [ "${REPLY,,}" = "z" ]; then
REPLY=$(zenity --file-selection --title="Select Install Dir for AppName" --filename="/usr/bin/$AppName" --directory)
  if [ -z "$REPLY" ]; then
  echo -n "User Cancelled, press return to quit. "
  read
  exit
  fi
fi

if [ -z "$REPLY" ]; then REPLY="$SDIR"; fi

RunCopy "$REPLY"

echo -n "All finished, press return to exit."
read
exit
}

# Run the copy command using sudo if root owns the directory
RunCopy() {
OWNER=$(ls -ld "$1"|grep drw|awk {'print $3'})
echo "Copying '$AppPath$AppName' to '$1/$AppName'"
if [ "$OWNER" = "root" ]; then
sudo cp "$AppPath$AppName" "$1/"
else
cp "$AppPath$AppName" "$1/"
fi
}


AppName="GForm"
AppPath="../"

CopyApplication

# Script end
